package deckbuilder;

import aesd.ds.exceptions.EmptyStackException;
import aesd.ds.implementations.linear.LinkedStack;
import aesd.ds.interfaces.Stack;
import br.com.davidbuzatto.jsge.core.engine.EngineFrame;
import br.com.davidbuzatto.jsge.image.Image;
import br.com.davidbuzatto.jsge.imgui.GuiButton;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.imageio.ImageIO;

public class DeckBuilderGame extends EngineFrame {

    private enum EstadoJogo {
        PLANEJAMENTO,
        RESOLVENDO_PILHA,
        VITORIA,
        DERROTA
    }

    private EstadoJogo estadoAtual;

    // Entidades
    private Entidade jogador;
    private Entidade inimigo;

    // Pilhas LIFO
    private Stack<Carta> drawPile;
    private Stack<Carta> discardPile;
    private Stack<Carta> pilhaDeResolucao;

    // Mão e Recursos
    private List<Carta> mao;
    private int energiaAtual;
    private final int ENERGIA_MAX = 3;

    // GUI
    private GuiButton btnResolverTurno;
    private GuiButton btnReiniciar;

    // Imagens carregadas
    private Image imgAtaque;
    private Image imgDefesa;
    private Image imgAtaquePesado;
    private Image imgFundoInimigo;
    private Image imgPlayer1;
    private Image imgPistaSalgada;

    // Controle da Resolução
    private double timerResolucao;
    private final double INTERVALO_ACAO = 1.0;
    private String registroAcao = "Declare suas cartas para contra-atacar!";
    private Carta cartaSendoResolvida = null;

    public DeckBuilderGame() {
        super( 900, 650, "Deck Builder - Combate em Pilha (LIFO)", 60, true );
    }

    @Override
    public void create() {
        useAsDependencyForIMGUI();

        // Carregamento de imagens convertendo BufferedImage para a Image da JSGE
        imgAtaque = carregarOuRedimensionar( "ataque.jpeg", 105, 130 );
        if ( imgAtaque == null ) imgAtaque = carregarOuRedimensionar( "ataque.png", 105, 130 );
        if ( imgAtaque == null ) imgAtaque = carregarOuRedimensionar( "ataque.jpg", 105, 130 );

        imgDefesa = carregarOuRedimensionar( "defesa.jpeg", 105, 130 );
        if ( imgDefesa == null ) imgDefesa = carregarOuRedimensionar( "defesa.png", 105, 130 );
        if ( imgDefesa == null ) imgDefesa = carregarOuRedimensionar( "defesa.jpg", 105, 130 );

        imgAtaquePesado = carregarOuRedimensionar( "ataque_pesado.jpeg", 105, 130 );
        if ( imgAtaquePesado == null ) imgAtaquePesado = carregarOuRedimensionar( "ataque_pesado.png", 105, 130 );
        if ( imgAtaquePesado == null ) imgAtaquePesado = carregarOuRedimensionar( "ataque_pesado.jpg", 105, 130 );

        imgFundoInimigo = carregarOuRedimensionar( "fundo_inimigo.jpeg", 160, 75 );
        if ( imgFundoInimigo == null ) imgFundoInimigo = carregarOuRedimensionar( "fundo_inimigo.png", 160, 75 );
        if ( imgFundoInimigo == null ) imgFundoInimigo = carregarOuRedimensionar( "fundo_inimigo.jpg", 160, 75 );

        imgPlayer1 = carregarOuRedimensionar( "fundo_player1.png", 90, 95 );
        if ( imgPlayer1 == null ) imgPlayer1 = carregarOuRedimensionar( "fundo_player1.jpeg", 90, 95 );
        if ( imgPlayer1 == null ) imgPlayer1 = carregarOuRedimensionar( "fundo_player1.jpg", 90, 95 );

        imgPistaSalgada = carregarOuRedimensionar( "pista_salgada.png", 85, 75 );
        if ( imgPistaSalgada == null ) imgPistaSalgada = carregarOuRedimensionar( "pista_salgada.jpeg", 85, 75 );
        if ( imgPistaSalgada == null ) imgPistaSalgada = carregarOuRedimensionar( "pista_salgada.jpg", 85, 75 );

        jogador = new Entidade( "Cavaleiro", 50 );
        inimigo = new Entidade( "Tríade Slime", 50 );

        drawPile = new LinkedStack<>();
        discardPile = new LinkedStack<>();
        pilhaDeResolucao = new LinkedStack<>();
        mao = new ArrayList<>();

        btnResolverTurno = new GuiButton( 720, 560, 150, 35, "Resolver Pilha" );
        btnReiniciar = new GuiButton( 375, 400, 150, 35, "Jogar Novamente" );

        montarDeckInicial();
        iniciarNovoTurno();
    }

    private Image carregarOuRedimensionar( String nomeArquivo, int largura, int altura ) {
        String[] caminhos = {
            "C:/Users/User/Desktop/ESDD/ProjetoESDLinear-master/recursos/" + nomeArquivo,
            "C:\\Users\\User\\Desktop\\ESDD\\ProjetoESDLinear-master\\recursos\\" + nomeArquivo,
            "recursos/" + nomeArquivo,
            "src/recursos/" + nomeArquivo
        };

        for ( String caminho : caminhos ) {
            File f = new File( caminho );
            if ( f.exists() ) {
                try {
                    BufferedImage bimg = ImageIO.read( f );
                    if ( bimg != null ) {
                        Image img = new Image( bimg );
                        return img.resize( largura, altura );
                    }
                } catch ( Exception ignored ) {}
            }
        }
        return null;
    }

    private void montarDeckInicial() {
        List<Carta> pool = new ArrayList<>();
        for ( int i = 0; i < 4; i++ ) {
            pool.add( new Carta( "Ataque", Carta.Tipo.ATAQUE, 6, 1, true, new Color( 180, 50, 50 ) ) );
        }
        for ( int i = 0; i < 4; i++ ) {
            pool.add( new Carta( "Defesa", Carta.Tipo.DEFESA, 5, 1, true, new Color( 50, 100, 180 ) ) );
        }
        pool.add( new Carta( "Ataque Pesado", Carta.Tipo.ESPECIAL, 12, 2, true, new Color( 140, 40, 140 ) ) );
        pool.add( new Carta( "Escudo Rígido", Carta.Tipo.DEFESA, 10, 2, true, new Color( 40, 130, 130 ) ) );

        Collections.shuffle( pool );
        for ( Carta c : pool ) {
            drawPile.push( c );
        }
    }

    private void iniciarNovoTurno() {
        jogador.resetarEscudo();
        inimigo.resetarEscudo();
        energiaAtual = ENERGIA_MAX;
        cartaSendoResolvida = null;
        estadoAtual = EstadoJogo.PLANEJAMENTO;

        while ( !mao.isEmpty() ) {
            discardPile.push( mao.remove( 0 ) );
        }

        for ( int i = 0; i < 4; i++ ) {
            if ( drawPile.isEmpty() ) {
                reabastecerDrawPile();
            }
            try {
                if ( !drawPile.isEmpty() ) {
                    mao.add( drawPile.pop() );
                }
            } catch ( EmptyStackException e ) {
                break;
            }
        }

        // Inimigo declara 2 ações na pilha LIFO
        Carta acao1;
        if ( Math.random() < 0.35 ) {
            acao1 = new Carta( "Salgar a Pista", Carta.Tipo.LIXO, 0, 0, false, new Color( 110, 40, 140 ) );
        } else {
            acao1 = new Carta( "Golpe Ácido", Carta.Tipo.ATAQUE, 7, 0, false, new Color( 160, 40, 40 ) );
        }
        pilhaDeResolucao.push( acao1 );

        Carta acao2;
        if ( Math.random() < 0.5 ) {
            acao2 = new Carta( "Gelatina Protetora", Carta.Tipo.DEFESA, 6, 0, false, new Color( 90, 90, 110 ) );
        } else {
            acao2 = new Carta( "Investida Rápida", Carta.Tipo.ATAQUE, 5, 0, false, new Color( 200, 70, 0 ) );
        }
        pilhaDeResolucao.push( acao2 );

        registroAcao = "Inimigo declarou ações! Analise a ordem da pilha.";
    }

    private void reabastecerDrawPile() {
        List<Carta> temp = new ArrayList<>();
        while ( !discardPile.isEmpty() ) {
            try {
                temp.add( discardPile.pop() );
            } catch ( EmptyStackException ignored ) {}
        }
        Collections.shuffle( temp );
        for ( Carta c : temp ) {
            drawPile.push( c );
        }
    }

    @Override
    public void update( double delta ) {
        if ( estadoAtual == EstadoJogo.VITORIA || estadoAtual == EstadoJogo.DERROTA ) {
            btnReiniciar.update( delta );
            if ( btnReiniciar.isMousePressed() ) {
                create();
            }
            return;
        }

        btnResolverTurno.update( delta );

        if ( estadoAtual == EstadoJogo.PLANEJAMENTO ) {
            if ( isMouseButtonPressed( MOUSE_BUTTON_LEFT ) ) {
                int mx = getMouseX();
                int my = getMouseY();

                for ( int i = 0; i < mao.size(); i++ ) {
                    int cardX = 220 + ( i * 115 );
                    int cardY = 500;
                    if ( mx >= cardX && mx <= cardX + 105 && my >= cardY && my <= cardY + 130 ) {
                        Carta c = mao.get( i );

                        if ( c.getTipo() == Carta.Tipo.LIXO ) {
                            registroAcao = "A pista está salgada! Não pode jogar esta carta.";
                            break;
                        }

                        if ( energiaAtual >= c.getCusto() ) {
                            energiaAtual -= c.getCusto();
                            mao.remove( i );
                            pilhaDeResolucao.push( c );
                            registroAcao = "Empilhou [" + c.getNome() + "]. Ela resolverá primeiro!";
                            break;
                        }
                    }
                }
            }

            if ( btnResolverTurno.isMousePressed() ) {
                estadoAtual = EstadoJogo.RESOLVENDO_PILHA;
                timerResolucao = 0;
            }

        } else if ( estadoAtual == EstadoJogo.RESOLVENDO_PILHA ) {
            timerResolucao += delta;
            if ( timerResolucao >= INTERVALO_ACAO ) {
                timerResolucao = 0;

                if ( !pilhaDeResolucao.isEmpty() ) {
                    try {
                        cartaSendoResolvida = pilhaDeResolucao.pop();
                        processarEfeito( cartaSendoResolvida );
                        discardPile.push( cartaSendoResolvida );
                    } catch ( EmptyStackException ignored ) {}

                    if ( !inimigo.estaVivo() ) {
                        estadoAtual = EstadoJogo.VITORIA;
                    } else if ( !jogador.estaVivo() ) {
                        estadoAtual = EstadoJogo.DERROTA;
                    }
                } else {
                    iniciarNovoTurno();
                }
            }
        }
    }

    private void processarEfeito( Carta c ) {
        if ( c.isDoJogador() ) {
            if ( c.getTipo() == Carta.Tipo.ATAQUE || c.getTipo() == Carta.Tipo.ESPECIAL ) {
                inimigo.receberDano( c.getValor() );
                registroAcao = "Executou " + c.getNome() + " causando " + c.getValor() + " de dano!";
            } else if ( c.getTipo() == Carta.Tipo.DEFESA ) {
                jogador.adicionarEscudo( c.getValor() );
                registroAcao = "Executou " + c.getNome() + " e obteve " + c.getValor() + " de escudo!";
            }
        } else {
            if ( c.getTipo() == Carta.Tipo.LIXO ) {
                Carta maldicao = new Carta( "Pista Salgada", Carta.Tipo.LIXO, 0, 1, true, new Color( 70, 70, 70 ) );
                drawPile.push( maldicao );
                registroAcao = "O inimigo salgou a pista! Uma carta inútil foi parar no seu deck!";
            } else if ( c.getTipo() == Carta.Tipo.ATAQUE || c.getTipo() == Carta.Tipo.ESPECIAL ) {
                jogador.receberDano( c.getValor() );
                registroAcao = "Inimigo atacou com " + c.getNome() + " causando " + c.getValor() + " de dano!";
            } else if ( c.getTipo() == Carta.Tipo.DEFESA ) {
                inimigo.adicionarEscudo( c.getValor() );
                registroAcao = "Inimigo ativou " + c.getNome() + " e reforçou sua defesa!";
            }
        }
    }

    @Override
    public void draw() {
        clearBackground( new Color( 25, 30, 40 ) );

        desenharPainelCombate();
        desenharPilhaDeResolucaoVisual();
        desenharMaoEJogador();

        drawRectangle( 180, 445, 540, 35, Color.DARK_GRAY );
        drawText( registroAcao, 195, 456, 14, Color.YELLOW );

        if ( estadoAtual == EstadoJogo.PLANEJAMENTO ) {
            btnResolverTurno.draw();
        }

        if ( estadoAtual == EstadoJogo.VITORIA || estadoAtual == EstadoJogo.DERROTA ) {
            desenharFimDeJogo();
        }
    }

    private void desenharPainelCombate() {
        // Jogador
        fillRectangle( 40, 30, 210, 140, new Color( 40, 50, 70 ) );
        drawRectangle( 40, 30, 210, 140, Color.WHITE );

        if ( imgPlayer1 != null ) {
            drawImage( imgPlayer1, 45, 50 );
        }

        drawText( jogador.getNome(), 145, 45, 15, Color.WHITE );
        drawText( "HP: " + jogador.getHpAtual() + "/" + jogador.getHpMax(), 145, 75, 14, Color.GREEN );
        drawText( "Escudo: " + jogador.getEscudo(), 145, 100, 14, Color.CYAN );

        // Inimigo
        fillRectangle( 650, 30, 210, 140, new Color( 70, 40, 40 ) );
        drawRectangle( 650, 30, 210, 140, Color.WHITE );

        if ( imgFundoInimigo != null ) {
            drawImage( imgFundoInimigo, 675, 80 );
        }

        drawText( inimigo.getNome(), 660, 45, 15, Color.WHITE );
        drawText( "HP: " + inimigo.getHpAtual() + "/" + inimigo.getHpMax(), 660, 65, 14, Color.RED );
        drawText( "Escudo: " + inimigo.getEscudo(), 770, 65, 14, Color.CYAN );

        drawText( "Pilha Compra: " + drawPile.getSize(), 40, 470, 14, Color.LIGHT_GRAY );
        drawText( "Pilha Descarte: " + discardPile.getSize(), 40, 490, 14, Color.LIGHT_GRAY );
    }

    private void desenharPilhaDeResolucaoVisual() {
        int xBase = 320;
        int yBase = 80;
        int larguraPilha = 260;
        int alturaPilha = 340;

        fillRectangle( xBase, yBase, larguraPilha, alturaPilha, new Color( 15, 20, 25 ) );
        drawRectangle( xBase, yBase, larguraPilha, alturaPilha, Color.GRAY );
        drawText( "PILHA DE RESOLUÇÃO (LIFO)", xBase + 25, yBase + 10, 14, Color.ORANGE );

        int slot = 0;
        for ( Carta c : pilhaDeResolucao ) {
            int itemY = ( yBase + alturaPilha - 45 ) - ( slot * 42 );

            fillRectangle( xBase + 15, itemY, 230, 36, c.getCor() );
            drawRectangle( xBase + 15, itemY, 230, 36, Color.WHITE );

            String autor = c.isDoJogador() ? "[Herói]" : "[Inimigo]";
            drawText( autor + " " + c.getNome(), xBase + 22, itemY + 8, 12, Color.WHITE );
            drawText( c.getDescricao(), xBase + 22, itemY + 22, 10, Color.LIGHT_GRAY );

            slot++;
        }

        if ( slot > 0 ) {
            int topoY = ( yBase + alturaPilha - 45 ) - ( ( slot - 1 ) * 42 );
            drawText( "<= TOPO (POP)", xBase + larguraPilha + 10, topoY + 12, 14, Color.YELLOW );
        } else {
            drawText( "Pilha Vazia", xBase + 95, yBase + 170, 14, Color.DARK_GRAY );
        }
    }

    private void desenharMaoEJogador() {
        drawText( "Energia: " + energiaAtual + "/" + ENERGIA_MAX, 220, 480, 16, Color.YELLOW );

        for ( int i = 0; i < mao.size(); i++ ) {
            Carta c = mao.get( i );
            int cardX = 220 + ( i * 115 );
            int cardY = 500;

            fillRectangle( cardX, cardY, 105, 130, c.getCor() );

            // Desenhar imagem correspondente se existir
            if ( c.getTipo() == Carta.Tipo.ATAQUE && imgAtaque != null ) {
                drawImage( imgAtaque, cardX, cardY );
            } else if ( c.getTipo() == Carta.Tipo.DEFESA && imgDefesa != null ) {
                drawImage( imgDefesa, cardX, cardY );
            } else if ( c.getTipo() == Carta.Tipo.ESPECIAL && imgAtaquePesado != null ) {
                drawImage( imgAtaquePesado, cardX, cardY );
            } else if ( c.getTipo() == Carta.Tipo.LIXO && imgPistaSalgada != null ) {
                drawImage( imgPistaSalgada, cardX + 10, cardY + 30 );
            }

            drawRectangle( cardX, cardY, 105, 130, Color.WHITE );

            // Identifica se a carta atual usa imagem
            boolean temArte = ( c.getTipo() == Carta.Tipo.ATAQUE && imgAtaque != null )
                    || ( c.getTipo() == Carta.Tipo.DEFESA && imgDefesa != null )
                    || ( c.getTipo() == Carta.Tipo.ESPECIAL && imgAtaquePesado != null );

            if ( temArte ) {
                // Badge de Custo de Energia (Canto superior esquerdo)
                fillCircle( cardX + 14, cardY + 14, 12, new Color( 30, 80, 180 ) );
                drawCircle( cardX + 14, cardY + 14, 12, Color.CYAN );
                drawText( String.valueOf( c.getCusto() ), cardX + 10, cardY + 7, 13, Color.WHITE );

                // Badge Inferior com Dano ou Escudo
                fillRectangle( cardX + 10, cardY + 104, 85, 20, new Color( 0, 0, 0, 200 ) );
                drawRectangle( cardX + 10, cardY + 104, 85, 20, Color.LIGHT_GRAY );
                String txtValor = ( c.getTipo() == Carta.Tipo.DEFESA ? "Escudo: " : "Dano: " ) + c.getValor();
                drawText( txtValor, cardX + 16, cardY + 108, 11, Color.YELLOW );
            } else {
                drawText( c.getNome(), cardX + 8, cardY + 12, 11, Color.WHITE );
                if ( c.getTipo() != Carta.Tipo.LIXO ) {
                    drawText( "Custo: " + c.getCusto(), cardX + 8, cardY + 28, 10, Color.YELLOW );
                }
                drawText( c.getDescricao(), cardX + 6, cardY + 112, 9, Color.LIGHT_GRAY );
            }
        }
    }

    private void desenharFimDeJogo() {
        fillRectangle( 250, 200, 400, 260, new Color( 0, 0, 0, 225 ) );
        drawRectangle( 250, 200, 400, 260, Color.WHITE );

        if ( estadoAtual == EstadoJogo.VITORIA ) {
            drawText( "VITÓRIA!", 385, 270, 32, Color.GREEN );
            drawText( "Derrotou os Slimes dominando a Pilha!", 285, 320, 14, Color.WHITE );
        } else {
            drawText( "DERROTA!", 380, 270, 32, Color.RED );
            drawText( "A pista salgada pesou e a pilha superou você...", 295, 320, 14, Color.WHITE );
        }

        btnReiniciar.draw();
    }

    public static void main( String[] args ) {
        new DeckBuilderGame();
    }
}