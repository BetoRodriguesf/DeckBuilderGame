package deckbuilder;

public class Entidade {

    private String nome;
    private int hpMax;
    private int hpAtual;
    private int escudo;

    public Entidade( String nome, int hpMax ) {
        this.nome = nome;
        this.hpMax = hpMax;
        this.hpAtual = hpMax;
        this.escudo = 0;
    }

    public void receberDano( int dano ) {
        if ( escudo > 0 ) {
            if ( dano <= escudo ) {
                escudo -= dano;
                return;
            } else {
                dano -= escudo;
                escudo = 0;
            }
        }
        hpAtual -= dano;
        if ( hpAtual < 0 ) {
            hpAtual = 0;
        }
    }

    public void adicionarEscudo( int valor ) {
        this.escudo += valor;
    }

    public void resetarEscudo() {
        this.escudo = 0;
    }

    public boolean estaVivo() {
        return hpAtual > 0;
    }

    public int getHpAtual() {
        return hpAtual;
    }

    public int getHpMax() {
        return hpMax;
    }

    public int getEscudo() {
        return escudo;
    }

    public String getNome() {
        return nome;
    }
}