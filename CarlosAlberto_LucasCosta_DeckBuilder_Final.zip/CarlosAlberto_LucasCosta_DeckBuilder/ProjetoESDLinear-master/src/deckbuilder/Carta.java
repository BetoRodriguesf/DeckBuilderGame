package deckbuilder;

import java.awt.Color;

public class Carta {

    public enum Tipo {
        ATAQUE, DEFESA, ESPECIAL, LIXO
    }

    private String nome;
    private Tipo tipo;
    private int valor;
    private int custo;
    private boolean doJogador;
    private Color cor;

    public Carta( String nome, Tipo tipo, int valor, int custo, boolean doJogador, Color cor ) {
        this.nome = nome;
        this.tipo = tipo;
        this.valor = valor;
        this.custo = custo;
        this.doJogador = doJogador;
        this.cor = cor;
    }

    public String getNome() {
        return nome;
    }

    public Tipo getTipo() {
        return tipo;
    }

    public int getValor() {
        return valor;
    }

    public int getCusto() {
        return custo;
    }

    public boolean isDoJogador() {
        return doJogador;
    }

    public Color getCor() {
        return cor;
    }

    public String getDescricao() {
        switch ( tipo ) {
            case ATAQUE: return "Dano: " + valor;
            case DEFESA: return "Escudo: " + valor;
            case ESPECIAL: return "Dano Pesado: " + valor;
            case LIXO: return "A pista está salgada!";
            default: return "";
        }
    }
}